<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\PolicyServiceProvider::class,
    App\Providers\VoltServiceProvider::class,
];
