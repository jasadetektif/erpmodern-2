<div>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e($analysisId ? __('Edit Analysis') : __('Create Analysis')); ?>

     <?php $__env->endSlot(); ?>

    <div class="py-4">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <form wire:submit.prevent="save">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 pb-6 border-b">
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700"><?php echo e(__('Analysis Name')); ?></label>
                        <input type="text" wire:model="name" id="name" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" placeholder="Contoh: 1 m3 Pekerjaan Beton K-225">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div>
                        <label for="unit" class="block text-sm font-medium text-gray-700"><?php echo e(__('Unit')); ?></label>
                        <input type="text" wire:model="unit" id="unit" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" placeholder="Contoh: m3, m2, ls">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4"><?php echo e(__('Labor Component')); ?></h3>
                    <div class="space-y-3">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--[if BLOCK]><![endif]--><?php if($item['type'] === 'labor'): ?>
                            <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-md" wire:key="item-labor-<?php echo e($index); ?>">
                                <div class="grid grid-cols-12 gap-3 flex-1">
                                    <div class="col-span-12 md:col-span-5">
                                        <select wire:model.live="items.<?php echo e($index); ?>.id" class="w-full border-gray-300 rounded-md shadow-sm">
                                            <option value=""><?php echo e(__('Select Labor')); ?></option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allLabors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($labor->id); ?>"><?php echo e($labor->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <div class="col-span-6 md:col-span-2">
                                        <input type="number" step="any" wire:model.live="items.<?php echo e($index); ?>.coefficient" placeholder="<?php echo e(__('Coefficient')); ?>" class="w-full border-gray-300 rounded-md shadow-sm">
                                    </div>
                                    <div class="col-span-6 md:col-span-2">
                                        <input type="text" value="<?php echo e($this->getUnitPrice($item['type'], $item['id'])); ?>" readonly class="w-full bg-gray-100 border-gray-300 rounded-md shadow-sm text-right">
                                    </div>
                                    <div class="col-span-12 md:col-span-3">
                                        <input type="text" value="Rp <?php echo e(number_format($this->calculateSubtotal($item), 2, ',', '.')); ?>" readonly class="w-full bg-gray-100 border-gray-300 rounded-md shadow-sm text-right font-semibold">
                                    </div>
                                </div>
                                <button wire:click.prevent="removeItem(<?php echo e($index); ?>)" class="text-red-500 hover:text-red-700 p-2">&times;</button>
                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <button wire:click.prevent="addLabor" class="mt-4 text-sm font-medium text-emerald-600 hover:text-emerald-800">+ <?php echo e(__('Add Labor')); ?></button>
                </div>

                
                <div class="mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4"><?php echo e(__('Material Component')); ?></h3>
                    <div class="space-y-3">
                         <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--[if BLOCK]><![endif]--><?php if($item['type'] === 'material'): ?>
                            <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-md" wire:key="item-material-<?php echo e($index); ?>">
                                <div class="grid grid-cols-12 gap-3 flex-1">
                                    <div class="col-span-12 md:col-span-5">
                                        <select wire:model.live="items.<?php echo e($index); ?>.id" class="w-full border-gray-300 rounded-md shadow-sm">
                                            <option value=""><?php echo e(__('Select Material')); ?></option>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($material->id); ?>"><?php echo e($material->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </select>
                                    </div>
                                    <div class="col-span-6 md:col-span-2">
                                        <input type="number" step="any" wire:model.live="items.<?php echo e($index); ?>.coefficient" placeholder="<?php echo e(__('Coefficient')); ?>" class="w-full border-gray-300 rounded-md shadow-sm">
                                    </div>
                                    <div class="col-span-6 md:col-span-2">
                                        <input type="text" value="<?php echo e($this->getUnitPrice($item['type'], $item['id'])); ?>" readonly class="w-full bg-gray-100 border-gray-300 rounded-md shadow-sm text-right">
                                    </div>
                                    <div class="col-span-12 md:col-span-3">
                                        <input type="text" value="Rp <?php echo e(number_format($this->calculateSubtotal($item), 2, ',', '.')); ?>" readonly class="w-full bg-gray-100 border-gray-300 rounded-md shadow-sm text-right font-semibold">
                                    </div>
                                </div>
                                <button wire:click.prevent="removeItem(<?php echo e($index); ?>)" class="text-red-500 hover:text-red-700 p-2">&times;</button>
                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <button wire:click.prevent="addMaterial" class="mt-4 text-sm font-medium text-emerald-600 hover:text-emerald-800">+ <?php echo e(__('Add Material')); ?></button>
                </div>

                
                <div class="mt-8 pt-4 border-t text-right">
                    <span class="text-sm font-medium text-gray-500"><?php echo e(__('Total Unit Price')); ?>:</span>
                    <span class="font-bold text-2xl text-gray-900 ml-2">Rp <?php echo e(number_format($total_cost, 2, ',', '.')); ?></span>
                </div>

                
                <div class="mt-8 flex justify-end">
                    <a href="<?php echo e(route('master.ahs.index')); ?>" class="bg-gray-200 text-gray-800 font-bold px-6 py-2 rounded-md hover:bg-gray-300 mr-4"><?php echo e(__('Back')); ?></a>
                    <button type="submit" class="bg-emerald-600 text-white font-bold px-6 py-2 rounded-md hover:bg-emerald-700"><?php echo e(__('Save Analysis')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/master/analysis/form.blade.php ENDPATH**/ ?>