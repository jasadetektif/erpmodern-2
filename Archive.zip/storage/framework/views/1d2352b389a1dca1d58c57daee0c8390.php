<div>
    
     <?php $__env->slot('header', null, []); ?>  <?php $__env->endSlot(); ?>

    
    <style>
        @keyframes marquee { 0% { transform: translateX(0%); } 100% { transform: translateX(-50%); } }
        .animate-marquee:hover { animation-play-state: paused; }
        .animate-marquee { animation: marquee 40s linear infinite; }
    </style>

    <div class="py-4 space-y-8">
        
        <!-- Header & Salam -->
        <div>
            <h1 class="text-3xl font-bold text-gray-800"><?php echo e(__($greeting)); ?>, <?php echo e(Auth::user()->name); ?>!</h1>
            <p class="text-gray-500 mt-1 italic">"<?php echo e(__($quote)); ?>"</p>
        </div>

        <!-- Teks Berjalan (Marquee) untuk Aktivitas Terbaru -->
        <!--[if BLOCK]><![endif]--><?php if(count($activityFeed) > 0): ?>
        <div class="bg-white rounded-xl shadow-md p-2 overflow-hidden">
            <div class="flex whitespace-nowrap animate-marquee">
                
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(1, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $activityFeed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center mx-4 py-2 flex-shrink-0">
                            <!--[if BLOCK]><![endif]--><?php if($activity['type'] === 'pr'): ?>
                                <div class="bg-blue-100 text-blue-600 p-2 rounded-full mr-3"><svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg></div>
                                <p class="text-sm text-gray-700">[<?php echo e($activity['timestamp']->setTimezone('Asia/Jakarta')->format('H:i')); ?> WIB] <?php echo e(__('PR')); ?> <span class="font-semibold"><?php echo e($activity['data']->pr_number); ?></span> <?php echo e(__('was just created by')); ?> <span class="font-semibold"><?php echo e($activity['data']->requester->name); ?></span>.</p>
                            <?php elseif($activity['type'] === 'po'): ?>
                                <div class="bg-green-100 text-green-600 p-2 rounded-full mr-3"><svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg></div>
                                <p class="text-sm text-gray-700">[<?php echo e($activity['timestamp']->setTimezone('Asia/Jakarta')->format('H:i')); ?> WIB] <?php echo e(__('PO')); ?> <span class="font-semibold"><?php echo e($activity['data']->po_number); ?></span> <?php echo e(__('was created for')); ?> <span class="font-semibold"><?php echo e($activity['data']->supplier->name); ?></span>.</p>
                            <?php elseif($activity['type'] === 'employee'): ?>
                                <div class="bg-indigo-100 text-indigo-600 p-2 rounded-full mr-3"><svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg></div>
                                <p class="text-sm text-gray-700">[<?php echo e($activity['timestamp']->setTimezone('Asia/Jakarta')->format('H:i')); ?> WIB] <span class="font-semibold"><?php echo e($activity['data']->user->name ?? $activity['data']->employee_id_number); ?></span> <?php echo e(__('was added as a new employee')); ?>.</p>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <span class="text-gray-300 self-center">&bull;</span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                         <p class="text-sm text-gray-500 mx-4"><?php echo e(__('No recent activity.')); ?></p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        
        <!-- Grid Utama -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2 space-y-8">
                <!-- Pusat Aksi & Pengumuman -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Kolom Pusat Aksi -->
                    <div class="bg-white p-6 rounded-xl shadow-lg border-t-4 border-amber-400">
                        <h3 class="font-semibold text-gray-800 mb-4"><?php echo e(__('Needs Your Attention')); ?></h3>
                        <div class="space-y-4">
                            <!--[if BLOCK]><![endif]--><?php if($pendingPrCount > 0): ?>
                            <a href="<?php echo e(route('procurement.pr.index')); ?>" class="flex items-center space-x-3 p-3 bg-amber-50 rounded-lg hover:bg-amber-100 transition">
                                <div class="bg-amber-100 text-amber-600 p-2 rounded-full"><svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg></div>
                                <div><p class="text-sm font-semibold text-gray-900"><?php echo e($pendingPrCount); ?> <?php echo e(__('Purchase Request')); ?></p><p class="text-xs text-gray-500"><?php echo e(__('Waiting for your approval')); ?></p></div>
                            </a>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($overdueInvoicesCount > 0): ?>
                            <a href="<?php echo e(route('finance.invoices.index')); ?>" class="flex items-center space-x-3 p-3 bg-red-50 rounded-lg hover:bg-red-100 transition">
                                 <div class="bg-red-100 text-red-600 p-2 rounded-full"><svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg></div>
                                <div><p class="text-sm font-semibold text-gray-900"><?php echo e($overdueInvoicesCount); ?> <?php echo e(__('Overdue Invoices')); ?></p><p class="text-xs text-gray-500"><?php echo e(__('Need to be paid immediately')); ?></p></div>
                            </a>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($pendingPrCount == 0 && $overdueInvoicesCount == 0): ?>
                            <p class="text-center text-gray-400 py-4"><?php echo e(__('All clear! No urgent actions needed.')); ?></p>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <!-- Kolom Pengumuman -->
                    <div class="bg-white p-6 rounded-xl shadow-lg border-t-4 border-blue-400">
                        <h3 class="font-semibold text-gray-800 mb-4"><?php echo e(__('Announcements')); ?></h3>
                        <!--[if BLOCK]><![endif]--><?php if($latestAnnouncement): ?>
                            <div class="space-y-2">
                                <p class="font-bold text-emerald-700"><?php echo e($latestAnnouncement->title); ?></p>
                                <p class="text-sm text-gray-600 line-clamp-3"><?php echo e($latestAnnouncement->content); ?></p>
                                <p class="text-xs text-gray-400 pt-2 border-t"><?php echo e(__('Posted by')); ?> <?php echo e($latestAnnouncement->user->name); ?> - <?php echo e($latestAnnouncement->created_at->diffForHumans()); ?></p>
                            </div>
                        <?php else: ?>
                            <p class="text-center text-gray-400 py-4"><?php echo e(__('No new announcements.')); ?></p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <!-- Grafik Profitabilitas Proyek -->
                <div class="bg-white p-6 rounded-xl shadow-md">
                    <h3 class="font-semibold text-gray-800 mb-4"><?php echo e(__('Project Profitability')); ?></h3>
                    <div class="h-80" wire:ignore><canvas id="profitabilityChart"></canvas></div>
                </div>
            </div>
            <!-- Kolom Samping Kanan (Statistik Kunci) -->
            <div class="lg:col-span-1 space-y-6">
                <div class="bg-gradient-to-br from-emerald-500 to-green-600 text-white p-6 rounded-xl shadow-lg">
                    <p class="text-sm font-medium opacity-80"><?php echo e(__('Ongoing Projects')); ?></p><p class="text-3xl font-bold mt-1"><?php echo e($activeProjects); ?></p>
                </div>
                <div class="bg-gradient-to-br from-sky-500 to-blue-600 text-white p-6 rounded-xl shadow-lg">
                    <p class="text-sm font-medium opacity-80"><?php echo e(__('Total Workers on Site')); ?></p><p class="text-3xl font-bold mt-1"><?php echo e($totalWorkers); ?></p>
                </div>
            </div>
        </div>
    </div>
    
        <?php
        $__scriptKey = '1717746185-0';
        ob_start();
    ?>
<script>
    document.addEventListener('livewire:navigated', () => {
        if (window.profitabilityChart && typeof window.profitabilityChart.destroy === 'function') {
            window.profitabilityChart.destroy();
        }

        const ctx = document.getElementById('profitabilityChart');
        if (ctx) {
            const chartData = <?php echo json_encode($profitabilityChartData, 15, 512) ?>;
            if (chartData && chartData.labels.length > 0) {
                window.profitabilityChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: chartData.labels,
                        datasets: [
                            {
                                label: '<?php echo e(__('Revenue')); ?>',
                                data: chartData.revenues,
                                backgroundColor: 'rgba(16, 185, 129, 0.6)',
                                borderColor: 'rgba(16, 185, 129, 1)',
                                borderWidth: 1,
                                borderRadius: 4
                            },
                            {
                                label: '<?php echo e(__('Expenses')); ?>',
                                data: chartData.expenses,
                                backgroundColor: 'rgba(239, 68, 68, 0.6)',
                                borderColor: 'rgba(239, 68, 68, 1)',
                                borderWidth: 1,
                                borderRadius: 4
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom' } },
                        scales: { y: { beginAtZero: true } }
                    }
                });
            }
        }
    });
</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/dashboard.blade.php ENDPATH**/ ?>