<div>
     <?php $__env->slot('header', null, []); ?> <?php echo e(__('Unit Price Analysis')); ?> <?php $__env->endSlot(); ?>

    <div class="py-4">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <!-- Header dan tombol tambah -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-semibold"><?php echo e(__('Unit Price Analysis List')); ?></h2>
                <a href="<?php echo e(route('master.ahs.form')); ?>"
                   class="bg-emerald-600 text-white font-bold px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors">
                    + <?php echo e(__('Add New Analysis')); ?>

                </a>
            </div>

            <!-- Flash Message -->
            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- Tabel AHS -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 text-sm">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Analysis Name')); ?></th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Unit')); ?></th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Total Unit Price')); ?></th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Items')); ?></th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $analyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-6 py-4 font-medium text-gray-900"><?php echo e($analysis->name); ?></td>
                                <td class="px-6 py-4 text-center text-gray-700"><?php echo e($analysis->unit); ?></td>
                                <td class="px-6 py-4 text-right text-gray-700">Rp <?php echo e(number_format($analysis->total_cost, 2, ',', '.')); ?></td>
                                <td class="px-6 py-4 text-center text-gray-700"><?php echo e($analysis->items_count); ?></td>
                                <td class="px-6 py-4 text-right space-x-2">
                                    <a href="<?php echo e(route('master.ahs.form', $analysis->id)); ?>"
                                       class="text-indigo-600 hover:text-indigo-900 font-medium">
                                       ✏️ <?php echo e(__('Edit')); ?>

                                    </a>
                                    <button
                                        x-data
                                        @click="if(confirm('<?php echo e(__('Are you sure you want to delete this analysis?')); ?>')) { $wire.delete(<?php echo e($analysis->id); ?>) }"
                                        class="text-red-600 hover:text-red-800 font-medium"
                                    >
                                        🗑️ <?php echo e(__('Delete')); ?>

                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                                    <?php echo e(__('No data available.')); ?>

                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/master/analysis/index.blade.php ENDPATH**/ ?>