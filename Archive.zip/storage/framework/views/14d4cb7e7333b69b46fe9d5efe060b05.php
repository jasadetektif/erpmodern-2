<div class="bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-xl font-semibold mb-4"><?php echo e(__('Project Timeline (Gantt Chart)')); ?></h2>
    <div class="min-h-[300px]" wire:ignore>
        <svg id="gantt"></svg>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(empty($ganttTasks)): ?>
        <p class="text-center text-gray-500 py-4">
            <?php echo e(__('Add tasks with start and end dates to see the Gantt chart.')); ?>

        </p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/projects/partials/gantt.blade.php ENDPATH**/ ?>