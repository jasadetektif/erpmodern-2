<div class="bg-white p-6 rounded-lg shadow-lg">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-semibold"><?php echo e(__('Task Management (WBS)')); ?></h2>
        <button wire:click="createTask()" class="bg-emerald-600 text-white font-bold px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors">
            + <?php echo e(__('Add New Task')); ?>

        </button>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Task Name')); ?></th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Start Date')); ?> - <?php echo e(__('End Date')); ?></th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Status')); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Actions')); ?></th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-6 py-4"><?php echo e($task->name); ?></td>
                        <td class="px-6 py-4">
                            <?php echo e($task->start_date ? \Carbon\Carbon::parse($task->start_date)->format('d M Y') : '-'); ?> 
                            s/d 
                            <?php echo e($task->end_date ? \Carbon\Carbon::parse($task->end_date)->format('d M Y') : '-'); ?>

                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                <?php echo e(__($task->status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-right text-sm font-medium">
                            <button wire:click="editTask(<?php echo e($task->id); ?>)" class="text-indigo-600 hover:text-indigo-900"><?php echo e(__('Edit')); ?></button>
                            <button wire:click="deleteTask(<?php echo e($task->id); ?>)" wire:confirm="<?php echo e(__('Are you sure you want to delete this task?')); ?>" class="text-red-600 hover:text-red-900 ml-4"><?php echo e(__('Delete')); ?></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-6 py-4 text-center text-gray-500"><?php echo e(__('No task data yet.')); ?></td></tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/projects/partials/tasks.blade.php ENDPATH**/ ?>