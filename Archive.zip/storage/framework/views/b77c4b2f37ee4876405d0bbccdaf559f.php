<div x-data="{ open: false }" wire:poll.10s="loadNotifications" class="relative">
    <button @click="open = !open" class="relative text-gray-500 hover:text-gray-700 focus:outline-none">
        
        <svg class="h-6 w-6 <?php if($unreadCount > 0): ?> animate-swing <?php endif; ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
        
        <!--[if BLOCK]><![endif]--><?php if($unreadCount > 0): ?>
            <span class="absolute top-0 right-0 block h-2 w-2 transform translate-x-1/2 -translate-y-1/2 rounded-full bg-red-500 ring-2 ring-white"></span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </button>

    
    <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg z-20">
        <div class="p-4 font-bold border-b"><?php echo e(__('Notifications')); ?></div>
        <div class="py-1">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex justify-between items-start">
        
        
        <?php $link = '#'; ?>
        <!--[if BLOCK]><![endif]--><?php if(isset($notification->data['project_id'])): ?>
            <?php $link = route('projects.show', $notification->data['project_id']); ?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if(isset($notification->data['pr_id'])): ?>
            <?php $link = route('procurement.pr.show', $notification->data['pr_id']); ?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <a href="<?php echo e($link); ?>" class="flex-1">
            <p><?php echo e($notification->data['message']); ?></p>
            <p class="text-xs text-gray-500 mt-1"><?php echo e($notification->created_at->diffForHumans()); ?></p>
        </a>

        <button wire:click="markAsRead('<?php echo e($notification->id); ?>')" title="Tandai sudah dibaca" class="text-gray-400 hover:text-blue-500 ml-2">&times;</button>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="px-4 py-3 text-sm text-gray-500"><?php echo e(__('No new notifications')); ?></p>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/notification-bell.blade.php ENDPATH**/ ?>