<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full bg-gray-100">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

    <!-- Scripts -->
      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
      
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

<style>
    @media print {
        /* Sembunyikan semua elemen yang tidak perlu dicetak */
        .no-print,
        body > div > div:not(.flex-1),
        body > div > div.flex-1 > header {
            display: none !important;
        }
        /* Pastikan konten utama memenuhi seluruh halaman cetak */
        body > div > div.flex-1 {
            margin-left: 0 !important;
        }
        body > div > div.flex-1 > main {
            padding: 0 !important;
        }
    }
</style>

    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="h-full font-sans antialiased">
    <div x-data="{ sidebarOpen: window.innerWidth > 1024 }" @resize.window="sidebarOpen = window.innerWidth > 1024">
        
        <!-- Sidebar -->
        <div 
            x-show="sidebarOpen" 
            x-transition:enter="transition-transform duration-300"
            x-transition:enter-start="-translate-x-full"
            x-transition:enter-end="translate-x-0"
            x-transition:leave="transition-transform duration-300"
            x-transition:leave-start="translate-x-0"
            x-transition:leave-end="-translate-x-full"
            class="fixed inset-y-0 left-0 z-40 w-64 bg-emerald-800 text-white flex flex-col"
            style="background-color: #1A4731;"
            @click.away="if (window.innerWidth < 1024) sidebarOpen = false"
        >
            <!-- Logo -->
            <div class="h-16 flex-shrink-0 flex items-center justify-center px-4 space-x-3">
                <svg class="h-8 w-8 text-emerald-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />
                </svg>
                <span class="text-xl font-bold">Arkavera App</span>
            </div>

            <!-- Navigasi Utama -->
<nav class="flex-1 px-4 py-4 space-y-2">
    <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors <?php echo e(request()->routeIs('dashboard') ? 'bg-emerald-700' : ''); ?>">
        <?php echo e(__('Dashboard')); ?>

    </a>
    


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage quotations')): ?>
<div x-data="{ open: <?php echo e(request()->routeIs('sales.*') ? 'true' : 'false'); ?> }" x-cloak>
    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
        <span><?php echo e(__('Sales')); ?></span>
        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
    </button>
    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
        <a href="<?php echo e(route('sales.quotations.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('sales.quotations.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Quotations')); ?>

        </a>
        <a href="<?php echo e(route('sales.clients.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('sales.clients.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Clients')); ?>

        </a>
    </div>
</div>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view projects')): ?>
    <a href="<?php echo e(route('projects.index')); ?>" class="flex items-center px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors <?php echo e(request()->routeIs('projects.index') ? 'bg-emerald-700' : ''); ?>">
        <?php echo e(__('Project Management')); ?>

    </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage assets')): ?>
<a href="<?php echo e(route('assets.index')); ?>" class="flex items-center px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors <?php echo e(request()->routeIs('assets.index') ? 'bg-emerald-700' : ''); ?>">
    <?php echo e(__('Asset Management')); ?>

</a>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view procurement')): ?>
    <div x-data="{ open: <?php echo e(request()->routeIs('procurement.*') ? 'true' : 'false'); ?> }" x-cloak>
        <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
            <span><?php echo e(__('Procurement')); ?></span>
            <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
        </button>
        <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
            <a href="<?php echo e(route('procurement.pr.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('procurement.pr.index') ? 'bg-emerald-700' : ''); ?>">
                <?php echo e(__('Purchase Requests')); ?>

            </a>
            <a href="<?php echo e(route('procurement.po.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('procurement.po.index') ? 'bg-emerald-700' : ''); ?>">
                <?php echo e(__('Purchase Orders')); ?>

            </a>
            <a href="<?php echo e(route('procurement.gr.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('procurement.gr.index') ? 'bg-emerald-700' : ''); ?>">
                <?php echo e(__('Goods Receipts')); ?>

            </a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage suppliers')): ?>
            <a href="<?php echo e(route('procurement.suppliers.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('procurement.suppliers.index') ? 'bg-emerald-700' : ''); ?>">
                <?php echo e(__('Suppliers')); ?>

            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view procurement')): ?>
<div x-data="{ open: <?php echo e(request()->routeIs('inventory.*') ? 'true' : 'false'); ?> }" x-cloak>
    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
        <span><?php echo e(__('Inventory')); ?></span>
        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
    </button>
    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
        <a href="<?php echo e(route('inventory.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('inventory.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Stock List')); ?>

        </a>
        <a href="<?php echo e(route('inventory.usage.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('inventory.usage.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Stock Usage')); ?>

        </a>
    </div>
</div>
<?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view finance')): ?>
                <div x-data="{ open: <?php echo e(request()->routeIs('finance.invoices.*') || request()->routeIs('finance.payments.*') ? 'true' : 'false'); ?> }" x-cloak>
                    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
                        <span><?php echo e(__('Accounts Payable')); ?></span>
                        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                    </button>
                    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
                        <a href="<?php echo e(route('finance.invoices.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('finance.invoices.index') ? 'bg-emerald-700' : ''); ?>"><?php echo e(__('Supplier Invoices')); ?></a>
                        <a href="<?php echo e(route('finance.payments.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('finance.payments.index') ? 'bg-emerald-700' : ''); ?>"><?php echo e(__('Supplier Payments')); ?></a>
                    </div>
                </div>
                <div x-data="{ open: <?php echo e(request()->routeIs('finance.client-invoices.*') || request()->routeIs('finance.client-payments.*') ? 'true' : 'false'); ?> }" x-cloak>
                    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
                        <span><?php echo e(__('Accounts Receivable')); ?></span>
                        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                    </button>
                    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
                        <a href="<?php echo e(route('finance.client-invoices.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('finance.client-invoices.index') ? 'bg-emerald-700' : ''); ?>"><?php echo e(__('Client Invoices')); ?></a>
                        <a href="<?php echo e(route('finance.client-payments.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('finance.client-payments.index') ? 'bg-emerald-700' : ''); ?>"><?php echo e(__('Client Payments')); ?></a>
                    </div>
                </div>
                <?php endif; ?>
                


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage hr')): ?>
<div x-data="{ open: <?php echo e(request()->routeIs('hr.*') ? 'true' : 'false'); ?> }" x-cloak>
    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
        <span><?php echo e(__('Human Resources')); ?></span>
        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
    </button>
    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
        <a href="<?php echo e(route('hr.employees.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('hr.employees.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Employee Management')); ?>

        </a>
        <a href="<?php echo e(route('hr.attendances.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('hr.attendances.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Attendance')); ?>

        <a href="<?php echo e(route('hr.payrolls.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('hr.payrolls.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Payroll')); ?>

        </a>
    </div>
</div>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view reports')): ?>
<div x-data="{ open: <?php echo e(request()->routeIs('reports.*') ? 'true' : 'false'); ?> }" x-cloak>
    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
        <span><?php echo e(__('Reports')); ?></span>
        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
    </button>
    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
        <a href="<?php echo e(route('reports.project-pl.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('reports.project-pl.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Project P&L')); ?>

        </a>
        <a href="<?php echo e(route('reports.cash-flow.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('reports.cash-flow.index') ? 'bg-emerald-700' : ''); ?>">
    <?php echo e(__('Cash Flow')); ?>

</a>
</a>
<a href="<?php echo e(route('reports.ap-aging.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('reports.ap-aging.index') ? 'bg-emerald-700' : ''); ?>">
    <?php echo e(__('A/P Aging')); ?>

</a>
<a href="<?php echo e(route('reports.ar-aging.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('reports.ar-aging.index') ? 'bg-emerald-700' : ''); ?>">
    <?php echo e(__('A/R Aging')); ?>

</a>
    </div>
</div>
<?php endif; ?>
    </a>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage master_data')): ?>
<div x-data="{ open: <?php echo e(request()->routeIs('master.*') ? 'true' : 'false'); ?> }" x-cloak>
    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
        <span><?php echo e(__('Master Data')); ?></span>
        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
    </button>
    <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
        <a href="<?php echo e(route('master.materials.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('master.materials.index') ? 'bg-emerald-700' : ''); ?>">
            <?php echo e(__('Materials')); ?>

        </a>
        <a href="<?php echo e(route('master.labors.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('master.labors.index') ? 'bg-emerald-700' : ''); ?>">
    <?php echo e(__('Labors')); ?>

</a>
<a href="<?php echo e(route('master.ahs.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('master.ahs.*') ? 'bg-emerald-700' : ''); ?>">
    <?php echo e(__('Unit Price Analysis')); ?>

</a>

    </div>
</div>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage settings')): ?>
                <div x-data="{ open: <?php echo e(request()->routeIs('settings.*') ? 'true' : 'false'); ?> }" x-cloak>
                    <button @click="open = !open" class="w-full flex justify-between items-center px-4 py-2 text-left rounded-md hover:bg-emerald-700 transition-colors">
                        <span><?php echo e(__('Settings')); ?></span>
                        <svg class="h-5 w-5 transition-transform" :class="{ 'rotate-180': open }" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                    </button>
                        <div x-show="open" x-collapse class="mt-2 pl-4 space-y-2">
                            <a href="<?php echo e(route('users.index')); ?>" class="flex items-center px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors <?php echo e(request()->routeIs('users.index') ? 'bg-emerald-700' : ''); ?>">
                             <?php echo e(__('User Management')); ?>

                             </a>
                        <a href="<?php echo e(route('settings.quotes.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('settings.quotes.index') ? 'bg-emerald-700' : ''); ?>">
                            <?php echo e(__('Quote Management')); ?>

                        </a>
                        <a href="<?php echo e(route('settings.announcements.index')); ?>" class="block px-4 py-2 rounded-md hover:bg-emerald-700 <?php echo e(request()->routeIs('settings.announcements.index') ? 'bg-emerald-700' : ''); ?>">
                            <?php echo e(__('Announcements')); ?>

                        </a>
                    </div>
                </div>
                <?php endif; ?>

</nav>
        </div>

        <!-- Konten Utama -->
        <div class="flex-1 flex flex-col" :class="{'lg:ml-64': sidebarOpen}">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
                <button @click="sidebarOpen = !sidebarOpen" class="text-gray-500 focus:outline-none">
                    <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 6H20M4 12H20M4 18H11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </button>
                
                <div class="flex items-center">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layout.navigation', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-939432379-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </header>

            <!-- Konten Halaman -->
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
                <?php if(isset($header)): ?>
                    <header class="mb-6">
                        <h1 class="text-2xl font-semibold text-gray-900">
                            <?php echo e($header); ?>

                        </h1>
                    </header>
                <?php endif; ?>
                
                <?php echo e($slot); ?>

            </main>
        </div>
    </div>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('global-search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-939432379-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>