<div>
<div class="container mx-auto p-4 sm:p-6 lg:p-8 bg-gray-100 min-h-screen font-inter">
    
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Project Detail')); ?>: <?php echo e($project->name); ?>

     <?php $__env->endSlot(); ?>

    
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div x-data="{ show: true }" x-show="show" x-transition.duration.300ms
            x-init="setTimeout(() => show = false, 3000)"
            class="mb-4 p-4 rounded-lg bg-green-500 text-white shadow-md"
            role="alert">
            <div class="flex items-center">
                <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span><?php echo e(__(session('message'))); ?></span>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="bg-white rounded-xl shadow-lg p-6 sm:p-8 mb-6">
        
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 pb-4 border-b border-gray-200">
            <h1 class="text-3xl font-bold text-gray-800 mb-2 sm:mb-0">
                <?php echo e($project->name); ?>

            </h1>
            <div class="text-sm text-gray-600">
                <span class="font-semibold"><?php echo e(__('Project Code')); ?>:</span> <?php echo e($project->project_code); ?>

            </div>
        </div>

        
        <div class="mb-6 border-b border-gray-200">
            <nav class="-mb-px flex flex-wrap gap-2 sm:gap-4 justify-center" aria-label="Tabs">
                <button wire:click="switchTab('overview')"
                    class="whitespace-nowrap px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200
                    <?php echo e($activeTab === 'overview' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e(__('Overview')); ?>

                </button>
                <button wire:click="switchTab('team')"
                    class="whitespace-nowrap px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200
                    <?php echo e($activeTab === 'team' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e(__('Team Management')); ?>

                </button>
                <button wire:click="switchTab('tasks')"
                    class="whitespace-nowrap px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200
                    <?php echo e($activeTab === 'tasks' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e(__('Task Management')); ?>

                </button>
                <button wire:click="switchTab('documents')"
                    class="whitespace-nowrap px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200
                    <?php echo e($activeTab === 'documents' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e(__('Documents')); ?>

                </button>
                <button wire:click="switchTab('expenses')"
                    class="whitespace-nowrap px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200
                    <?php echo e($activeTab === 'expenses' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e(__('Other Expenses')); ?>

                </button>
                <button wire:click="switchTab('rab')"
                    class="whitespace-nowrap px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200
                    <?php echo e($activeTab === 'rab' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <?php echo e(__('RAB')); ?>

                </button>
            </nav>
        </div>

        
        <div>
            <!--[if BLOCK]><![endif]--><?php if($activeTab === 'overview'): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <div class="bg-indigo-50 p-6 rounded-lg shadow-sm">
                        <h3 class="text-xl font-semibold text-indigo-700 mb-4"><?php echo e(__('Project Details')); ?></h3>
                        <p class="mb-2"><strong class="text-gray-700"><?php echo e(__('Description')); ?>:</strong> <?php echo e($project->description); ?></p>
                        <p class="mb-2"><strong class="text-gray-700"><?php echo e(__('Start Date')); ?>:</strong> <?php echo e($project->start_date ? \Carbon\Carbon::parse($project->start_date)->format('d M Y') : 'N/A'); ?></p>
                        <p class="mb-2"><strong class="text-gray-700"><?php echo e(__('End Date')); ?>:</strong> <?php echo e($project->end_date ? \Carbon\Carbon::parse($project->end_date)->format('d M Y') : 'N/A'); ?></p>
                        <p class="mb-2"><strong class="text-gray-700"><?php echo e(__('Client')); ?>:</b> <?php echo e($project->client_name); ?></p>
                        <p class="mb-2"><strong class="text-gray-700"><?php echo e(__('Status')); ?>:</b> <span class="px-2 py-1 rounded-full text-xs font-semibold
                            <?php if($project->status === 'In Progress'): ?> bg-blue-100 text-blue-800
                            <?php elseif($project->status === 'Completed'): ?> bg-green-100 text-green-800
                            <?php else: ?> bg-yellow-100 text-yellow-800 <?php endif; ?>">
                            <?php echo e(__($project->status)); ?>

                        </span></p>
                        <p class="mb-2"><strong class="text-gray-700"><?php echo e(__('Budget')); ?>:</strong> Rp <?php echo e(number_format($project->budget, 0, ',', '.')); ?></p>
                        <div class="mt-4">
                            <h4 class="text-lg font-semibold text-gray-700 mb-2"><?php echo e(__('Project Progress')); ?></h4>
                            <div class="w-full bg-gray-200 rounded-full h-2.5">
                                <div class="bg-indigo-600 h-2.5 rounded-full"
                                    style="width: <?php echo e($project->progress > 100 ? 100 : $project->progress); ?>%;"></div>
                            </div>
                            <p class="text-right text-sm text-gray-600 mt-1"><?php echo e(number_format($project->progress, 2)); ?>% <?php echo e(__('Completed')); ?></p>
                        </div>
                    </div>

                    
                    <div class="bg-green-50 p-6 rounded-lg shadow-sm">
                        <h2 class="text-xl font-semibold text-green-700 mb-4"><?php echo e(__('Financial Summary')); ?></h2>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                            <div>
                                <h3 class="text-sm font-medium text-gray-500"><?php echo e(__('Contract Value')); ?></h3>
                                <p class="mt-1 text-2xl font-bold text-gray-900">Rp <?php echo e(number_format($project->budget, 0, ',', '.')); ?></p>
                            </div>
                            <div>
                                <h3 class="text-sm font-medium text-gray-500"><?php echo e(__('Material Expenses')); ?></h3>
                                <p class="mt-1 text-lg font-semibold text-red-500">Rp <?php echo e(number_format($project->purchaseOrders->sum('total_amount'), 0, ',', '.')); ?></p>
                            </div>
                            <div>
                                <h3 class="text-sm font-medium text-gray-500"><?php echo e(__('Actual Labor Cost (from Payroll)')); ?></h3>
                                <p class="mt-1 text-lg font-semibold text-red-500">Rp <?php echo e(number_format($project->total_labor_cost, 0, ',', '.')); ?></p>
                            </div>
                            <div>
                                <h3 class="text-sm font-medium text-gray-500"><?php echo e(__('Other Expenses')); ?></h3>
                                <p class="mt-1 text-lg font-semibold text-red-500">Rp <?php echo e(number_format($project->otherExpenses->sum('amount'), 0, ',', '.')); ?></p>
                            </div>
                            <div class="col-span-1 lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4 mt-4">
                                <div>
                                    <h3 class="text-sm font-medium text-gray-500"><?php echo e(__('Total Expenses')); ?></h3>
                                    <p class="mt-1 text-xl font-bold text-red-600">Rp <?php echo e(number_format($totalExpenses, 0, ',', '.')); ?></p>
                                </div>
                                <div>
                                    <h3 class="text-sm font-medium text-gray-500"><?php echo e(__('Actual Profit / Loss')); ?></h3>
                                    <p class="mt-1 text-2xl font-bold <?php echo e($profitOrLoss >= 0 ? 'text-green-600' : 'text-red-600'); ?>">Rp <?php echo e(number_format($profitOrLoss, 0, ',', '.')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($activeTab === 'team'): ?>
                
                <div class="bg-white p-6 rounded-lg shadow-sm">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-semibold"><?php echo e(__('Project Workforce')); ?></h2>
                        <button wire:click="openTeamModal" class="bg-indigo-600 text-white font-bold px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                            + <?php echo e(__('Assign Foreman')); ?>

                        </button>
                    </div>
                    <div class="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Foreman Name')); ?></th>
                                    <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Payment Type')); ?></th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Total Cost (2 Weeks)')); ?></th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $project->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $cost = 0;
                                        if ($team->payment_type == 'harian') {
                                            $mandorSalary = ($team->employee->basic_salary ?? 0) / 2; // Asumsi gaji dasar adalah bulanan, dibagi 2 untuk 2 minggu
                                            $workerWages = $team->number_of_workers * $team->worker_daily_wage * 12; // 12 hari dalam 2 minggu (6 hari/minggu)
                                            $cost = $mandorSalary + $workerWages;
                                        } else {
                                            $cost = $team->lump_sum_value * ($team->work_progress / 100);
                                        }
                                    ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e($team->employee->user->name ?? $team->employee->employee_id_number); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-center">
                                            <span class="px-2 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-800"><?php echo e(__($team->payment_type)); ?></span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-right font-bold">Rp <?php echo e(number_format($cost, 2, ',', '.')); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <button wire:click="editTeam(<?php echo e($team->id); ?>)" class="text-indigo-600 hover:text-indigo-900 mr-3"><?php echo e(__('Edit')); ?></button>
                                            <button wire:click="removeMandor(<?php echo e($team->id); ?>)" wire:confirm="<?php echo e(__('Are you sure?')); ?>" class="text-red-600 hover:text-red-900"><?php echo e(__('Remove')); ?></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="4" class="px-6 py-4 text-center text-gray-600 italic"><?php echo e(__('No foreman has been assigned to this project.')); ?></td></tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($activeTab === 'tasks'): ?>
                
                <div class="bg-white p-6 rounded-lg shadow-sm mb-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-semibold"><?php echo e(__('Task Management (WBS)')); ?></h2>
                        <button wire:click="createTask()" class="bg-indigo-600 text-white font-bold px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                            + <?php echo e(__('Add New Task')); ?>

                        </button>
                    </div>
                    <div class="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Task Name')); ?></th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Start Date')); ?> - <?php echo e(__('End Date')); ?></th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Status')); ?></th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e($task->name); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($task->start_date ? \Carbon\Carbon::parse($task->start_date)->format('d M Y') : '-'); ?> <?php echo e(__('s/d')); ?> <?php echo e($task->end_date ? \Carbon\Carbon::parse($task->end_date)->format('d M Y') : '-'); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <span class="px-2 py-1 rounded-full text-xs font-semibold
                                                <?php if($task->status === 'Selesai'): ?> bg-green-100 text-green-800
                                                <?php elseif($task->status === 'Sedang Dikerjakan'): ?> bg-blue-100 text-blue-800
                                                <?php else: ?> bg-yellow-100 text-yellow-800 <?php endif; ?>">
                                                <?php echo e(__($task->status)); ?>

                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <button wire:click="editTask(<?php echo e($task->id); ?>)" class="text-indigo-600 hover:text-indigo-900 mr-3"><?php echo e(__('Edit')); ?></button>
                                            <button wire:click="deleteTask(<?php echo e($task->id); ?>)" wire:confirm="<?php echo e(__('Are you sure you want to delete this task?')); ?>" class="text-red-600 hover:text-red-900"><?php echo e(__('Delete')); ?></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="4" class="px-6 py-4 text-center text-gray-600 italic"><?php echo e(__('No task data yet.')); ?></td></tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>

                
                <div class="bg-white p-6 rounded-lg shadow-sm">
                    <h2 class="text-xl font-semibold mb-4"><?php echo e(__('Project Timeline (Gantt Chart)')); ?></h2>
                    <div class="min-h-[300px]" wire:ignore>
                        <svg id="gantt"></svg>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if(empty($ganttTasks)): ?>
                        <p class="text-center text-gray-500 py-4"><?php echo e(__('Add tasks with start and end dates to see the Gantt chart.')); ?></p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($activeTab === 'documents'): ?>
                
                <div class="bg-white p-6 rounded-lg shadow-sm">
                    <h3 class="text-2xl font-semibold text-gray-800 mb-4"><?php echo e(__('Project Documents')); ?></h3>
                    <form wire:submit.prevent="uploadDocument" class="mb-6 p-4 border border-dashed border-gray-300 rounded-lg bg-gray-50">
                        <label for="document" class="block text-sm font-medium text-gray-700 mb-2"><?php echo e(__('Upload New Document (Max 10MB)')); ?></label>
                        <input type="file" wire:model="document" id="document"
                            class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4
                            file:rounded-md file:border-0 file:text-sm file:font-semibold
                            file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <button type="submit"
                            class="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-150 ease-in-out"
                            wire:loading.attr="disabled" wire:target="document">
                            <span wire:loading.remove wire:target="document"><?php echo e(__('Upload Document')); ?></span>
                            <span wire:loading wire:target="document"><?php echo e(__('Uploading...')); ?></span>
                        </button>
                    </form>

                    <!--[if BLOCK]><![endif]--><?php if($project->documents->isEmpty()): ?>
                        <p class="text-gray-600 italic"><?php echo e(__('No documents uploaded for this project yet.')); ?></p>
                    <?php else: ?>
                        <div class="space-y-3">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $project->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between p-3 bg-white border rounded-md hover:bg-gray-50">
                                    <div class="flex items-center space-x-3">
                                        <!--[if BLOCK]><![endif]--><?php if(Str::contains($doc->type, 'pdf')): ?>
                                            <svg class="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                        <?php else: ?>
                                            <svg class="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <div>
                                            <a href="<?php echo e(Storage::disk('public')->url($doc->path)); ?>" target="_blank" class="font-semibold text-gray-800 hover:underline"><?php echo e($doc->name); ?></a>
                                            <p class="text-xs text-gray-500"><?php echo e(__('Uploaded by')); ?> <?php echo e($doc->uploadedBy->name); ?> <?php echo e(__('on')); ?> <?php echo e(\Carbon\Carbon::parse($doc->created_at)->format('d M Y')); ?></p>
                                        </div>
                                    </div>
                                    <button wire:click="deleteDocument(<?php echo e($doc->id); ?>)" wire:confirm="<?php echo e(__('Are you sure?')); ?>" class="text-red-600 hover:text-red-900"><?php echo e(__('Delete')); ?></button>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($activeTab === 'expenses'): ?>
                
                <div class="bg-white p-6 rounded-lg shadow-sm">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-xl font-semibold"><?php echo e(__('Other Expenses')); ?></h2>
                        <button wire:click="openExpenseModal" class="bg-indigo-600 text-white font-bold px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                            + <?php echo e(__('Add Expense')); ?>

                        </button>
                    </div>
                    <div class="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Date')); ?></th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Description')); ?></th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Amount')); ?></th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Recorded By')); ?></th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $project->otherExpenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e(\Carbon\Carbon::parse($expense->expense_date)->format('d M Y')); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($expense->description); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-right">Rp <?php echo e(number_format($expense->amount, 2, ',', '.')); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($expense->user->name); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <button wire:click="deleteExpense(<?php echo e($expense->id); ?>)" wire:confirm="<?php echo e(__('Are you sure?')); ?>" class="text-red-600 hover:text-red-900"><?php echo e(__('Delete')); ?></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="5" class="px-6 py-4 text-center text-gray-600 italic"><?php echo e(__('No other expense data available.')); ?></td></tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        
            <!--[if BLOCK]><![endif]--><?php if($activeTab === 'rab'): ?>
                
                <div class="bg-white p-6 rounded-lg shadow-sm">
                    <h3 class="text-2xl font-semibold text-gray-800 mb-4"><?php echo e(__('RAB (Cost Budget Plan)')); ?></h3>

                    <div class="mb-4 flex flex-wrap gap-2">
                        <button wire:click="addRabItem('PEKERJAAN PERSIAPAN')" class="px-4 py-2 bg-blue-500 text-white rounded-md shadow hover:bg-blue-600 text-sm"><?php echo e(__('Add Preparation Work')); ?></button>
                        <button wire:click="addRabItem('PEKERJAAN STRUKTUR')" class="px-4 py-2 bg-blue-500 text-white rounded-md shadow hover:bg-blue-600 text-sm"><?php echo e(__('Add Structure Work')); ?></button>
                        <button wire:click="addRabItem('PEKERJAAN ARSITEKTUR')" class="px-4 py-2 bg-blue-500 text-white rounded-md shadow hover:bg-blue-600 text-sm"><?php echo e(__('Add Architecture Work')); ?></button>
                        <button wire:click="addRabItem('PEKERJAAN UTILITAS')" class="px-4 py-2 bg-blue-500 text-white rounded-md shadow hover:bg-blue-600 text-sm"><?php echo e(__('Add Utility Work')); ?></button>
                        <button wire:click="addRabItem('LAIN-LAIN')" class="px-4 py-2 bg-blue-500 text-white rounded-md shadow hover:bg-blue-600 text-sm"><?php echo e(__('Add Other Work')); ?></button>
                    </div>

                    <form wire:submit.prevent="saveRab">
                        <div class="overflow-x-auto rounded-lg border border-gray-200 shadow-sm mb-6">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Category')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('AHS')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Description')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20"><?php echo e(__('Qty')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20"><?php echo e(__('Unit')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32"><?php echo e(__('Unit Price')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32"><?php echo e(__('Total Price')); ?></th>
                                        <th scope="col" class="px-3 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Actions')); ?></th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    
                                    <?php
                                        $currentCategory = null;
                                        $categorySubtotal = 0;
                                    ?>

                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $rabItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $originalIndex => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <!--[if BLOCK]><![endif]--><?php if($item['category'] !== $currentCategory): ?>
                                            <!--[if BLOCK]><![endif]--><?php if($currentCategory !== null): ?>
                                                
                                                <tr class="bg-gray-50">
                                                    <td colspan="6" class="px-3 py-2 text-right text-sm font-semibold text-gray-700">
                                                        <?php echo e(__('Subtotal')); ?> <?php echo e(__($currentCategory)); ?>:
                                                    </td>
                                                    <td colspan="2" class="px-3 py-2 text-left text-sm font-bold text-gray-800">
                                                        Rp <?php echo e(number_format($categorySubtotal, 0, ',', '.')); ?>

                                                    </td>
                                                </tr>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            
                                            <tr class="bg-gray-100">
                                                <td colspan="8" class="px-3 py-2 text-left text-sm font-semibold text-gray-800">
                                                    <?php echo e(__($item['category'])); ?>

                                                </td>
                                            </tr>
                                            <?php
                                                $currentCategory = $item['category'];
                                                $categorySubtotal = 0;
                                            ?>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                        <tr wire:key="rab-item-<?php echo e($item['id'] ?? $originalIndex); ?>"> 
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                
                                                <select wire:model.live="rabItems.<?php echo e($originalIndex); ?>.category"
                                                    class="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-xs">
                                                    <option value="PEKERJAAN PERSIAPAN"><?php echo e(__('Preparation Work')); ?></option>
                                                    <option value="PEKERJAAN STRUKTUR"><?php echo e(__('Structure Work')); ?></option>
                                                    <option value="PEKERJAAN ARSITEKTUR"><?php echo e(__('Architecture Work')); ?></option>
                                                    <option value="PEKERJAAN UTILITAS"><?php echo e(__('Utility Work')); ?></option>
                                                    <option value="LAIN-LAIN"><?php echo e(__('Other Work')); ?></option>
                                                </select>
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <select wire:model.live="rabItems.<?php echo e($originalIndex); ?>.analysis_id"
                                                    class="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-xs">
                                                    <option value=""><?php echo e(__('Select Analysis (Optional)')); ?></option>
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $analysisList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analysis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($analysis->id); ?>"><?php echo e($analysis->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                </select>
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <textarea wire:model.live="rabItems.<?php echo e($originalIndex); ?>.description" rows="2"
                                                    class="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-xs"></textarea>
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["rabItems.{$originalIndex}.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <input type="number" step="0.01" wire:model.live="rabItems.<?php echo e($originalIndex); ?>.quantity"
                                                    class="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-xs">
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <input type="text" wire:model.live="rabItems.<?php echo e($originalIndex); ?>.unit"
                                                    class="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-xs">
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                <input type="number" step="0.01" wire:model.live="rabItems.<?php echo e($originalIndex); ?>.unit_price"
                                                    class="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 text-xs">
                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">
                                                Rp <?php echo e(number_format($item['total_price'], 0, ',', '.')); ?>

                                            </td>
                                            <td class="px-3 py-3 whitespace-nowrap text-right text-sm font-medium">
                                                <button type="button" wire:click="removeRabItem(<?php echo e($originalIndex); ?>)" class="text-red-600 hover:text-red-900 text-xs"><?php echo e(__('Remove')); ?></button>
                                            </td>
                                        </tr>
                                        <?php
                                            $categorySubtotal += $item['total_price'];
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="8" class="px-6 py-4 text-center text-gray-600 italic"><?php echo e(__('No RAB items added yet. Click \'Add Work\' to start.')); ?></td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    
                                    <!--[if BLOCK]><![endif]--><?php if($currentCategory !== null): ?>
                                        <tr class="bg-gray-50">
                                            <td colspan="6" class="px-3 py-2 text-right text-sm font-semibold text-gray-700">
                                                <?php echo e(__('Subtotal')); ?> <?php echo e(__($currentCategory)); ?>:
                                            </td>
                                            <td colspan="2" class="px-3 py-2 text-left text-sm font-bold text-gray-800">
                                                Rp <?php echo e(number_format($categorySubtotal, 0, ',', '.')); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="6" class="px-6 py-3 text-right text-base font-semibold text-gray-800 bg-gray-50 rounded-bl-lg"><?php echo e(__('Total RAB')); ?>:</td>
                                        <td colspan="2" class="px-6 py-3 text-left text-base font-bold text-gray-800 bg-gray-50 rounded-br-lg">
                                            Rp <?php echo e(number_format($totalRabAmount, 0, ',', '.')); ?>

                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <div class="flex justify-end">
                            <button type="submit"
                                class="px-6 py-2 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                                <?php echo e(__('Save RAB')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            

        </div> 
    </div> 

    
    <!--[if BLOCK]><![endif]--><?php if($isTeamModalOpen): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                    <h3 class="text-lg font-bold text-gray-800"><?php echo e(__('Assign Foreman to Project')); ?></h3>
                    <button wire:click="closeTeamModal" class="text-gray-500 hover:text-gray-700">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <form wire:submit.prevent="assignMandor" class="mt-4">
                    <div class="mb-4">
                        <label for="team_employee_id" class="block text-sm font-medium text-gray-700"><?php echo e(__('Select Foreman')); ?></label>
                        <select wire:model="team_employee_id" id="team_employee_id"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value=""><?php echo e(__('Select an Employee')); ?></option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $mandorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mandor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mandor->id); ?>"><?php echo e($mandor->user->name ?? $mandor->employee_id_number); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['team_employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="mb-4">
                        <label for="team_payment_type" class="block text-sm font-medium text-gray-700"><?php echo e(__('Payment Type')); ?></label>
                        <div class="mt-2 space-x-4">
                            <label class="inline-flex items-center"><input type="radio" wire:model.live="team_payment_type" value="harian" class="form-radio text-indigo-600"> <span class="ml-2"><?php echo e(__('Daily')); ?></span></label>
                            <label class="inline-flex items-center"><input type="radio" wire:model.live="team_payment_type" value="borongan" class="form-radio text-indigo-600"> <span class="ml-2"><?php echo e(__('Lump Sum')); ?></span></label>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['team_payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($team_payment_type === 'harian'): ?>
                        <div class="mb-4">
                            <label for="team_number_of_workers" class="block text-sm font-medium text-gray-700"><?php echo e(__('Number of Workers')); ?></label>
                            <input type="number" wire:model="team_number_of_workers" id="team_number_of_workers"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['team_number_of_workers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-4">
                            <label for="team_worker_daily_wage" class="block text-sm font-medium text-gray-700"><?php echo e(__('Worker Daily Wage')); ?> (Rp)</label>
                            <input type="number" wire:model="team_worker_daily_wage" id="team_worker_daily_wage"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['team_worker_daily_wage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <div class="mb-4">
                            <label for="team_lump_sum_value" class="block text-sm font-medium text-gray-700"><?php echo e(__('Lump Sum Value')); ?> (Rp)</label>
                            <input type="number" wire:model="team_lump_sum_value" id="team_lump_sum_value"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['team_lump_sum_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-4">
                            <label for="team_work_progress" class="block text-sm font-medium text-gray-700"><?php echo e(__('Work Progress')); ?> (%)</label>
                            <input type="number" wire:model="team_work_progress" id="team_work_progress"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" min="0" max="100">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['team_work_progress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="flex justify-end gap-2 mt-4">
                        <button type="button" wire:click="closeTeamModal"
                            class="px-4 py-2 bg-gray-300 text-gray-800 rounded-md shadow hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Cancel')); ?>

                        </button>
                        <button type="submit"
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Assign')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php if($isTeamEditModalOpen && $editingTeam): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                    <h3 class="text-lg font-bold text-gray-800"><?php echo e(__('Edit Team Assignment')); ?> for <?php echo e($editingTeam->employee->user->name ?? 'N/A'); ?></h3>
                    <button wire:click="closeTeamEditModal" class="text-gray-500 hover:text-gray-700">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <form wire:submit.prevent="updateTeam" class="mt-4">
                    <div class="mb-4">
                        <label for="editingTeam_payment_type" class="block text-sm font-medium text-gray-700"><?php echo e(__('Payment Type')); ?></label>
                        <div class="mt-2 space-x-4">
                            <label class="inline-flex items-center"><input type="radio" wire:model.live="editingTeam.payment_type" value="harian" class="form-radio text-indigo-600"> <span class="ml-2"><?php echo e(__('Daily')); ?></span></label>
                            <label class="inline-flex items-center"><input type="radio" wire:model.live="editingTeam.payment_type" value="borongan" class="form-radio text-indigo-600"> <span class="ml-2"><?php echo e(__('Lump Sum')); ?></span></label>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editingTeam.payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($editingTeam->payment_type === 'harian'): ?>
                        <div class="mb-4">
                            <label for="editingTeam_number_of_workers" class="block text-sm font-medium text-gray-700"><?php echo e(__('Number of Workers')); ?></label>
                            <input type="number" wire:model="editingTeam.number_of_workers" id="editingTeam_number_of_workers"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editingTeam.number_of_workers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-4">
                            <label for="editingTeam_worker_daily_wage" class="block text-sm font-medium text-gray-700"><?php echo e(__('Worker Daily Wage')); ?> (Rp)</label>
                            <input type="number" wire:model="editingTeam.worker_daily_wage" id="editingTeam_worker_daily_wage"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editingTeam.worker_daily_wage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php else: ?>
                        <div class="mb-4">
                            <label for="editingTeam_lump_sum_value" class="block text-sm font-medium text-gray-700"><?php echo e(__('Lump Sum Value')); ?> (Rp)</label>
                            <input type="number" wire:model="editingTeam.lump_sum_value" id="editingTeam_lump_sum_value"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editingTeam.lump_sum_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-4">
                            <label for="editingTeam_work_progress" class="block text-sm font-medium text-gray-700"><?php echo e(__('Work Progress')); ?> (%)</label>
                            <input type="number" wire:model="editingTeam.work_progress" id="editingTeam_work_progress"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" min="0" max="100">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editingTeam.work_progress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="flex justify-end gap-2 mt-4">
                        <button type="button" wire:click="closeTeamEditModal"
                            class="px-4 py-2 bg-gray-300 text-gray-800 rounded-md shadow hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Cancel')); ?>

                        </button>
                        <button type="submit"
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Update')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php if($isTaskModalOpen): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-lg p-6">
                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                    <h3 class="text-lg font-bold text-gray-800"><?php echo e($taskId ? __('Edit Task') : __('Add New Task')); ?></h3>
                    <button wire:click="closeTaskModal" class="text-gray-500 hover:text-gray-700">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <form wire:submit.prevent="storeTask" class="mt-4">
                    <div class="mb-4">
                        <label for="task_name" class="block text-sm font-medium text-gray-700"><?php echo e(__('Task Name')); ?></label>
                        <input type="text" wire:model="task_name" id="task_name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['task_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="mb-4">
                        <label for="task_description" class="block text-sm font-medium text-gray-700"><?php echo e(__('Description')); ?></label>
                        <textarea wire:model="task_description" id="task_description" rows="3"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['task_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label for="task_start_date" class="block text-sm font-medium text-gray-700"><?php echo e(__('Start Date')); ?></label>
                            <input type="date" wire:model="task_start_date" id="task_start_date"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['task_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div>
                            <label for="task_end_date" class="block text-sm font-medium text-gray-700"><?php echo e(__('End Date')); ?></label>
                            <input type="date" wire:model="task_end_date" id="task_end_date"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['task_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="task_progress" class="block text-sm font-medium text-gray-700"><?php echo e(__('Progress')); ?> (%)</label>
                        <input type="range" wire:model="task_progress" id="task_progress" min="0" max="100"
                            class="mt-1 block w-full">
                        <p class="text-center font-semibold"><?php echo e($task_progress ?? 0); ?>%</p>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['task_progress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="flex justify-end gap-2 mt-4">
                        <button type="button" wire:click="closeTaskModal"
                            class="px-4 py-2 bg-gray-300 text-gray-800 rounded-md shadow hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Cancel')); ?>

                        </button>
                        <button type="submit"
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e($taskId ? __('Update Task') : __('Create Task')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php if($isExpenseModalOpen): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
                <div class="flex justify-between items-center pb-3 border-b border-gray-200">
                    <h3 class="text-lg font-bold text-gray-800"><?php echo e(__('Add Other Expense')); ?></h3>
                    <button wire:click="closeExpenseModal" class="text-gray-500 hover:text-gray-700">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
                <form wire:submit.prevent="storeExpense" class="mt-4">
                    <div class="mb-4">
                        <label for="expense_description" class="block text-sm font-medium text-gray-700"><?php echo e(__('Description')); ?></label>
                        <textarea wire:model="expense_description" id="expense_description" rows="3"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['expense_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="mb-4">
                        <label for="expense_amount" class="block text-sm font-medium text-gray-700"><?php echo e(__('Amount')); ?> (Rp)</label>
                        <input type="number" wire:model="expense_amount" id="expense_amount"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['expense_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="flex justify-end gap-2 mt-4">
                        <button type="button" wire:click="closeExpenseModal"
                            class="px-4 py-2 bg-gray-300 text-gray-800 rounded-md shadow hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Cancel')); ?>

                        </button>
                        <button type="submit"
                            class="px-4 py-2 bg-indigo-600 text-white rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-150 ease-in-out">
                            <?php echo e(__('Add Expense')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <link rel="stylesheet" href="https://unpkg.com/frappe-gantt@0.6.0/dist/frappe-gantt.min.css" />
    <script src="https://unpkg.com/frappe-gantt@0.6.0/dist/frappe-gantt.min.js"></script>

        <?php
        $__scriptKey = '2770605404-0';
        ob_start();
    ?>
    <script>
        document.addEventListener('livewire:navigated', () => {
            const tasks = <?php echo json_encode($ganttTasks, 15, 512) ?>;
            const ganttEl = document.querySelector("#gantt");

            if (ganttEl) {
                // Hancurkan instance Gantt sebelumnya jika ada
                if (window.ganttChartInstance) {
                    window.ganttChartInstance.destroy();
                }
                ganttEl.innerHTML = ''; // Bersihkan elemen SVG sebelumnya

                console.log("GANTT TASKS (Livewire):", tasks); // Log data dari Livewire

                if (tasks && tasks.length > 0) {
                    try {
                        const formattedTasks = tasks.map(t => {
                            let progress = parseInt(t.progress);
                            progress = isNaN(progress) ? 0 : progress; // Pastikan progres adalah angka
                            return {
                                id: t.id.toString(),
                                name: t.name,
                                start: new Date(t.start).toISOString().split('T')[0], // Pastikan format tanggal YYYY-MM-DD
                                end: new Date(t.end).toISOString().split('T')[0],     // Pastikan format tanggal YYYY-MM-DD
                                progress: progress,
                                dependencies: t.dependencies || '' // Tambahkan dependensi jika ada
                            };
                        });
                        console.log("GANTT TASKS (Formatted for Frappe):", formattedTasks); // Log data setelah diformat

                        // Inisialisasi Gantt chart
                        window.ganttChartInstance = new Gantt("#gantt", formattedTasks, { // Gunakan formattedTasks
                            on_click: (task) => {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('editTask', task.id);
                            },
                            bar_height: 20,
                            padding: 18,
                            view_mode: 'Day' // Set default view mode
                            // Hapus opsi 'language' agar tetap dalam bahasa Inggris (default Frappe Gantt)
                        });

                    } catch(e) {
                        console.error("Error creating Gantt instance: ", e);
                    }
                }
            }
        });
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
    </div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/projects/show.blade.php ENDPATH**/ ?>