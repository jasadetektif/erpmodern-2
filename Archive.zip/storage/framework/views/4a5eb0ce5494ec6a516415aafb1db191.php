<div class="bg-white p-6 rounded-lg shadow-lg">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold"><?php echo e(__('Other Expenses')); ?></h2>
        <button wire:click="openExpenseModal" class="bg-emerald-600 text-white font-bold px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors">
            + <?php echo e(__('Add Expense')); ?>

        </button>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Date')); ?></th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Description')); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Amount')); ?></th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Recorded By')); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase"><?php echo e(__('Actions')); ?></th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $project->otherExpenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e(\Carbon\Carbon::parse($expense->expense_date)->format('d M Y')); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($expense->description); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-right">Rp <?php echo e(number_format($expense->amount, 2, ',', '.')); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($expense->user->name); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button wire:click="deleteExpense(<?php echo e($expense->id); ?>)" wire:confirm="<?php echo e(__('Are you sure?')); ?>" class="text-red-600 hover:text-red-900"><?php echo e(__('Delete')); ?></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                            <?php echo e(__('No other expense data available.')); ?>

                        </td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/erpmodern 2/resources/views/livewire/projects/partials/expenses.blade.php ENDPATH**/ ?>