import './bootstrap';

import Gantt from 'frappe-gantt';
window.Gantt = Gantt;

import Chart from 'chart.js/auto';
window.Chart = Chart;
